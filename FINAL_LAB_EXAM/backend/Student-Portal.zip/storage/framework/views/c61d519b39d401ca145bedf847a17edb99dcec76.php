

<?php $__env->startSection('content'); ?>
    <div class="row">
        <table class="table table-striped" id="table1">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Active Posts</th>
                    <th>Delete</th>
                    <th>Edit</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($cat->name); ?></td>
                        <td><?php echo e(count($cat->posts)); ?></td>
                        <td><a href="<?php echo e(route('admin.categories.delete', ['id' => $cat->id])); ?>" class="btn btn-danger">Delete</a></td>
                        <td>
                            <a href="<?php echo e(route('admin.categories.edit', ['id' => $cat->id])); ?>" class="btn btn-secondary">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
        

<?php echo $__env->make('admin.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\Xampp\htdocs\Student-Portal\resources\views/admin/categories/all.blade.php ENDPATH**/ ?>