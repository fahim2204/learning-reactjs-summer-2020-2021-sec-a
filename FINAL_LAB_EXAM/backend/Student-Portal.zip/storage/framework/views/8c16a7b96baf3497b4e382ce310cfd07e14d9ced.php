

<?php $__env->startSection('content'); ?>
    <div class="row">
        <table class="table table-striped" id="table1">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Joined At</th>
                    <th>Designation</th>
                    <th>View</th>
                    <th>Approve</th>
                    <th>Decline</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->uname); ?></td>
                    <td><?php echo e($user->created_at->DiffForHumans()); ?></td>
                    <td><?php echo e($user->type); ?></td>
                    <td><a href="<?php echo e(route('admin.users.view', ['id' => $user->id])); ?>" class="btn btn-primary">View</a></td>
                    <td><a href="<?php echo e(route('admin.moderator.approve', ['id' => $user->id])); ?>" class="btn btn-success">Approve</a></td>
                    <td><a href="<?php echo e(route('admin.moderator.decline', ['id' => $user->id])); ?>" class="btn btn-danger">Decline</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('moderator.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\Xampp\htdocs\Student-Portal\resources\views/admin/moderator-requests.blade.php ENDPATH**/ ?>