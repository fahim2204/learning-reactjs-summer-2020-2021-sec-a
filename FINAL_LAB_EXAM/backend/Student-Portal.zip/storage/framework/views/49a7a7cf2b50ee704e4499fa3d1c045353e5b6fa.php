
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="create-post col-sm">
        <form action="<?php echo e(route('admin.posts.create')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="post-title" class="form-label">Post Title</label>
                <input type="text" class="form-control" id="post-title" name="post-title">
            </div>
            <div class="mb-3">
                <label for="post-description" class="form-label">Post Description</label>
                <textarea class="form-control" name="post-description" id="post-description" rows="3"></textarea>
            </div>
            <div class="row">
                <div class="col-sm">
                    <input list="brow" name="post-category" class="form-select">
                    <datalist id="brow" class="">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" label="<?php echo e($category->name); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </datalist>  
                </div>
            </div>
            <div class="mb-3 mt-2">
                <label for="formFile" class="form-label">Add Image</label>
                <input class="form-control" type="file" id="formFile" name="featured_image">
              </div>
            <button type="submit" class="btn btn-primary">Post</button>
        </form>
    </div>
    <div class="preview col-sm">

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\Xampp\htdocs\Student-Portal\resources\views/admin/posts/create.blade.php ENDPATH**/ ?>