<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(session()->get('uname') !== null): ?>
    <?php echo $__env->yieldContent('header-main-logged'); ?>
<?php else: ?>
    <?php echo $__env->yieldContent('header-main'); ?>
<?php endif; ?>

<div class="container">
    <div class="main-body">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="main-breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Profile</li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($user->uname); ?></li>
            </ol>
        </nav>
        <!-- /Breadcrumb -->

        <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-column align-items-center text-center">
                            <?php if($user->$type->image===null): ?>
                            <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="StudentProfilePic" class="rounded-circle" width="150">
                            <?php else: ?>
                            <img src="<?php echo e(asset('upload/'.$user->$type->image)); ?>" alt="StudentProfilePic" class="rounded-circle" width="150">
                            <?php endif; ?>
                            <div class="mt-3">
                                <h4><?php echo e('@' . $user->uname); ?></h4>
                                <p class="text-secondary mb-1"><?php echo e($user->type); ?></p>
                                <button class="btn btn-primary">Follow</button>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('msg.view',$user->uname)); ?>">Message</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card mt-3">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap rounded-top bg-primary text-white">Social Link</li>
                        <?php $__currentLoopData = $slinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap p-0 px-3">
                            <h6 class="mb-0"><img class="me-2 align-self-center" src="https://img.icons8.com/ios-glyphs/20/000000/link--v2.png"/><?php echo e($slink->sname); ?></h6>
                            <span class="text-secondary"><a href="<?php echo e($slink->link); ?>"><?php echo e($slink->link); ?></a></span>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php if(session()->get('type')==='instructor'): ?>
                <div class="card mt-3">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap rounded-top bg-success text-white">Qualifications</li>
                        <?php $__currentLoopData = $qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qualification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                            <div class="mb-0 me-2"><img class="me-2 align-self-center" src="https://img.icons8.com/ios-glyphs/20/000000/certificate.png"/><?php echo e($qualification->degree); ?> <small>(<?php echo e($qualification->year); ?>)</small></div>
                            <div class="text-secondary">Grade: <?php echo e($qualification->grade); ?></div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-md-8">
                <div class="card mb-3">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-3">
                                <h6 class="mb-0">Full Name</h6>
                            </div>
                            <div class="col-sm-9 text-secondary">
                                <?php echo e($user->$type->name); ?>

                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <h6 class="mb-0">Email</h6>
                            </div>
                            <div class="col-sm-9 text-secondary">
                                <?php echo e($user->$type->email); ?>

                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <h6 class="mb-0">Phone</h6>
                            </div>
                            <div class="col-sm-9 text-secondary">
                                <?php echo e($user->$type->contact); ?>

                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <h6 class="mb-0">Address</h6>
                            </div>
                            <div class="col-sm-9 text-secondary">
                                <?php echo e($user->$type->address); ?>

                            </div>
                        </div>

                        
                        <?php if($user->uname == session()->get('uname')): ?>
                            <hr>
                            <div class="row d-flex justify-content-end">
                                <div class="col-2 align-content-end">
                                    <a class="btn btn-info" href="<?php echo e(route('profile.edit')); ?>">Edit</a>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>

                <div class="col-md-12">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="container posts">
                            <!-- Single Post -->
                            <div class="row post mb-2 border-1 shadow-sm border-secondary">
                                <div class="col-3">
                                    <div class="row post-attr text-center">
                                        
                                            
                                        <div class="col-6">
                                            <?php echo e(count($post->comments)); ?><br />
                                            <b>Comment</b>
                                        </div>
                                        <div class="col-6">
                                            <?php echo e($post->views); ?><br />
                                            <b>Views</b>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-9">
                                    <div class="container">
                                        <h5><a
                                                href="<?php echo e(route('posts.view.single', [$post->category->name, $post->id])); ?>"><?php echo e($post->title); ?></a>
                                        </h5>
                                        <?php echo e(\Illuminate\Support\Str::limit($post->pbody, 200, '....')); ?> <a
                                            href="<?php echo e(route('posts.view.single', [$post->category->name, $post->id])); ?>"
                                            class='text-primary'>Read More</a>

                                        
                                    </div>
                                </div>
                            </div>
                            <!-- Single Post end -->
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

    </div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Installed\Xampp\htdocs\Student-Portal\resources\views/profile/view.blade.php ENDPATH**/ ?>