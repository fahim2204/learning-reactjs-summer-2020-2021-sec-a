<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(session()->get('uname') !== null): ?>
    <?php echo $__env->yieldContent('header-main-logged'); ?>
<?php else: ?>
    <?php echo $__env->yieldContent('header-main'); ?>
<?php endif; ?>

<div class="container my-4">
    <div class="row">
        <div class="col-md-9 mx-auto border border-2 shadow-lg rounded">

            <h3 class="text-center mb-4">Message</h3>
            <div class="row">
                <div class="col-3">
                    <?php $__currentLoopData = $msgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-success rounded-3 shadow my-2 mx-1 py-2 px-2">
                            <a class="text-decoration-none text-white" href="<?php echo e(route('msg.view',$msg->sender->uname)); ?>"><?php echo e($msg->sender->uname); ?></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-9">
                    <div class="border rounded-3 border-3 p-4">
                        <?php $__currentLoopData = $msgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-light rounded-3 my-2 mx-1 py-2 px-2 d-inline">
                            <div class="">
                                <?php echo e($msg->msg); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>


        </div>

    </div>
</div>






<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Installed\Xampp\htdocs\Student-Portal\resources\views/message/index.blade.php ENDPATH**/ ?>