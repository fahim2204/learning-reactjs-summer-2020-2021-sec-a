

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="create-post col-sm">
            <form action="<?php echo e(route('admin.categories.create')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="post-title" class="form-label">Category Name</label>
                    <input type="text" name="name" class="form-control" id="post-title" name="post-title">
                </div>
                <?php if(session()->has('success')): ?>
                <p class="text-success"><?php echo e(session('success')); ?></p>
                <?php endif; ?>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($msg); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button type="submit" class="btn btn-primary">Create</button>
            </form>
        </div>
        <div class="preview col-sm">

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\Xampp\htdocs\Student-Portal\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>