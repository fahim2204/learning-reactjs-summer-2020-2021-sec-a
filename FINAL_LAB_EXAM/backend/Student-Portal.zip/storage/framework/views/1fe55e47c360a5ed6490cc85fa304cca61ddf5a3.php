

<?php $__env->startSection('content'); ?>
    <div class="row">
        <table class="table table-striped" id="table1">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Joined At</th>
                    <th>Designation</th>
                    <th>View</th>
                    <th>Delete</th>
                    <th>Ban</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->uname); ?></td>
                    <td><?php echo e($user->created_at->DiffForHumans()); ?></td>
                    <td><?php echo e($user->type); ?></td>
                    <td><a href="<?php echo e(route('admin.users.view', ['id' => $user->id])); ?>" class="btn btn-primary">View</a></td>
                    <td><a href="<?php echo e(route('admin.users.delete', ['id' => $user->id])); ?>" class="btn btn-danger">Delete</a></td>
                    <?php if($user->status === 1): ?>
                    <td><a href="<?php echo e(route('admin.users.ban', ['id' => $user->id])); ?>" class="btn btn-secondary">Ban</a></td>
                    <?php else: ?>
                    <td><a href="<?php echo e(route('admin.users.unban', ['id' => $user->id])); ?>" class="btn btn-success">Unban</a></td>
                    <?php endif; ?>
                </tr>              
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
        

<?php echo $__env->make('admin.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\Xampp\htdocs\Student-Portal\resources\views/admin/users/all.blade.php ENDPATH**/ ?>