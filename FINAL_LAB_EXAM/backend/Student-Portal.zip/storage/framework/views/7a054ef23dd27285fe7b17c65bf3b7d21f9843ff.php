
<?php $__env->startSection('content'); ?>
    <div class="row">
        <table class="table table-striped" id="table1">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Date</th>
                    <th>Author</th>
                    <th>Delete</th>
                    <th>View</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e(strtotime($post->created_at)); ?></td>
                    <td><?php echo e($post->user->uname); ?></td>
                    <td><a href="<?php echo e(route('admin.posts.delete', ['id'=> $post->id ])); ?>" class="btn btn-danger">Delete</a></td>
                    <td>
                        <a href="<?php echo e(route('posts.view.single', ['subcat' => $post->category->name, 'id' => $post->id])); ?>" class="btn btn-success">View</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>
    </div>
    
<?php $__env->stopSection(); ?>
        


<?php echo $__env->make('admin.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\Xampp\htdocs\Student-Portal\resources\views/admin/posts/all.blade.php ENDPATH**/ ?>