<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(session()->get('uname') !== null): ?>
    <?php echo $__env->yieldContent('header-main-logged'); ?>
<?php else: ?>
    <?php echo $__env->yieldContent('header-main'); ?>
<?php endif; ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-9 mx-auto ">

            <h1>Create post</h1>

            <form action="" method="POST">

                <div class="form-group has-error">
                    <label for="category">Category</label>
                    <select class="form-select" aria-label="Default select example" name="category">
                        <option selected>--Select a Category--</option>
                        <?php $__currentLoopData = $catall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                </div>
                <div class="form-group">
                    <label for="title">Title </label>
                    <input type="text" class="form-control" name="title" placeholder="Your Title" />
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea rows="5" class="form-control" name="description" placeholder="Type Your text Here"></textarea>
                </div>

                <div class="form-group my-2">
                    <button type="submit" class="btn btn-primary me-3">
                        Create
                    </button>
                    <a class="btn btn-outline-danger" href="<?php echo e(route('home')); ?>">
                        Cancel
                    </a>
                </div>

            </form>
            <?php if(session('msg')!= null): ?>
                <div class="alert alert-danger d-flex justify-content-center my-2" role="alert">
                    <?php echo e(session('msg')); ?>

                </div>
            <?php endif; ?>
        </div>

    </div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Installed\Xampp\htdocs\Student-Portal\resources\views/posts/create-post.blade.php ENDPATH**/ ?>