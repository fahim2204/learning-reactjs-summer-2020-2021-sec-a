let table1 = document.querySelector('#table1');
let dataTable = new simpleDatatables.DataTable(table1);