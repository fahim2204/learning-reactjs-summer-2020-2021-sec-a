<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class moderator extends Model
{
    // protected $table = 'moderator';
    // protected $primaryKey = 'userId';
    // public $timestamps = false;

    // const created_at = 'create_time';
    // const UPDATED_AT = 'update_time';
}
